first run the program as it is without changing anything so that it is easy to understand how the web app works

 open the folder mywebapp

 to start server type command
	python .\manage.py  runserver

(directory should be mywebapp)

after that open the webpage in browser at 127.0.0.1:8000

the main code for ML is in directory 
	" mywebapp/imgUpload/views.py

need to change the main code and then need to change the html code according to our requirement

