from django.apps import AppConfig


class ImguploadConfig(AppConfig):
    name = 'imgUpload'
